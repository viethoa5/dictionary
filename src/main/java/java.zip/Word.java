public class Word {
        private String word_target;
        private String word_expand;
        public Word() {
            word_target = new String();
            word_expand = new String();
        }
        public Word(String word_target, String word_expand) {
            this.word_target = word_target;
            this.word_expand = word_expand;
        }

        public String getWord_expand() {
            return word_expand;
        }

        public String getWord_target() {
            return word_target;
        }

        public void setWord_expand(String word_expand) {
            this.word_expand = word_expand;
        }

        public void setWord_target(String word_target) {
            this.word_target = word_target;
        }
}
