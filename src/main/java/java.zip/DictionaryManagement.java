import java.util.Scanner;
import java.util.Arrays;

public class DictionaryManagement {
    public static Word[] wordArrays = new Word[100000];

    public void insertFromCommandline() {
        Scanner scan = new Scanner(System.in);
        int size = scan.nextInt();
        for (int i = 0; i < size; i++) {
            Word words = new Word();
            String define = scan.nextLine();
            String meaning = scan.nextLine();
            words.setWord_target(define);
            words.setWord_expand(meaning);
            Dictionary.wordArrays[i] = new Word(words.getWord_target(),words.getWord_expand());
        }
    }
}
