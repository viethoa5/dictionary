public class Dictionary {
        public static Word[] wordArrays;
        public static int size;
        public Dictionary(int size) {
            wordArrays = new Word[size];
        }
        public void writewordArrays() {
            for(int i = 0; i < size; i++) {
                wordArrays[i] = new Word();
            }
        }
}
