import org.apache.commons.lang3.StringUtils;
public class DictionaryCommandline {
    DictionaryManagement manage = new DictionaryManagement();
    public void showAllWords() {
        System.out.println("No   | English     | Vietnamese");
        int numth = 0;
        for(Word word : DictionaryManagement.wordArrays) {
            if(word != null) {
                System.out.print(numth+1);
                System.out.print("   | " + StringUtils.capitalize(word.getWord_target()) +"       | ");
                System.out.print(StringUtils.capitalize(word.getWord_expand()));
                System.out.println();
                numth++;
            }
        }
    }
    public void dictionaryBasic() {
        manage.insertFromCommandline();
        showAllWords();
    }
}
