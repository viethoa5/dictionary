public class Main {
    public static void main(String[] args) {
        DictionaryCommandline commnands = new DictionaryCommandline();
        commnands.dictionaryBasic();
    }
}
